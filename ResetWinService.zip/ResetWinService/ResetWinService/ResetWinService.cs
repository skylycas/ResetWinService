﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Timers;

namespace ResetWinService
{
    public partial class ResetWinService : ServiceBase
    {
        Timer timer = new Timer();
        string stringsourcefile = @"C:\LCBO Applications\ResetPanGPS\ResetPanGPS.txt";
        string stringsourceDirectory = @"C:\LCBO Applications\ResetPanGPS";
        public ResetWinService()
        {
            InitializeComponent();
        }


        //public void onDebug()
        //{
        //    OnStart(null);
        //}

        public void readFileContect()
        {
            if(!File.Exists(stringsourcefile))
            {
                if(!Directory.Exists(stringsourceDirectory))
                {
                    DirectoryInfo directory = Directory.CreateDirectory(stringsourceDirectory);
                }
                //Create text file
                CreateTextFile();
                ////uncomment below to use this part for allowing the app to reset any service
                //using(StreamWriter streamWriter = File.CreateText(stringsourcefile))
                //{
                //    streamWriter.WriteLine("/*Please do not delete this line,on the next line write the name of the service and action to perfom eg. PanGPS=restart or PanGPS=start or PanGPS=stop */");
                //}
            }
            else
            {
                string[] stringArr = File.ReadAllLines(stringsourcefile);


                ////uncomment below to use this part for allowing the app to reset any service
                //int indexToRemove = 0;
                //stringArr = stringArr.Where((source, index) => index != indexToRemove).ToArray();


                if(stringArr.Length > 0)
                {
                    foreach (string str in stringArr)
                    {
                        //if (str.Contains("="))
                        //{
                        //    string[] splitValues = str.Split('=');
                        //    string serviceName = splitValues[0];
                        //    string serviceAction = splitValues[1];
                        string serviceName = "PanGPS";
                        string serviceAction = str.Trim().ToLower();
                        switch (serviceAction)
                        {
                            case "start":
                                StartService(serviceName, 10000);
                                break;
                            case "stop":
                                StopService(serviceName, 10000);
                                break;
                            case "restart":
                                RestartService(serviceName, 10000);
                                break;
                            default: break;
                        }
                        // }
                    }
                }


            }

        }


        public void CreateTextFile()
        {
            using (StreamWriter streamWriter = File.CreateText(stringsourcefile))
            {

            }
        }

        public void WriteInTextFile(string valtext)
        {
            using (StreamWriter streamWriter = File.AppendText(stringsourcefile))
            {
                streamWriter.WriteLine(valtext + DateTime.Now);
            }
        }


        public void KillTask()
        {
            foreach(Process process in Process.GetProcessesByName("PanGPS"))
            {
                process.Kill();
            }
            foreach (Process process in Process.GetProcessesByName("PanGPA"))
            {
                process.Kill();
            }
        }


        public void StartService(string serviceName, int timeoutMilliseconds)
        {
            ServiceController serviceController = new ServiceController(serviceName);
            try
            {
                KillTask();

                TimeSpan timeout = TimeSpan.FromMilliseconds(timeoutMilliseconds);
                if (serviceController.Status.Equals(ServiceControllerStatus.Stopped) || serviceController.Status.Equals(ServiceControllerStatus.StartPending))
                {
                    serviceController.Start();
                    serviceController.WaitForStatus(ServiceControllerStatus.Running, timeout);
                }


                CreateTextFile();

                //WriteInTextFile("Start Service executed here");
            }
            catch(Exception ex)
            {
                writeError(ex.Message);
            }
        }



        public void StopService(string serviceName, int timeoutMilliseconds)
        {
            try
            {

                KillTask();

                ServiceController serviceController = new ServiceController(serviceName);
                TimeSpan timeout = TimeSpan.FromMilliseconds(timeoutMilliseconds);
                if(serviceController.Status.Equals(ServiceControllerStatus.Running) || serviceController.Status.Equals(ServiceControllerStatus.StopPending))
                {
                    serviceController.Stop();
                    serviceController.WaitForStatus(ServiceControllerStatus.Stopped, timeout);
                }


                CreateTextFile();

                //WriteInTextFile("Stop Service executed here");
            }
            catch (Exception ex)
            {
                writeError(ex.Message);
            }
        }


        public void RestartService(string serviceName, int timeoutMilliseconds)
        {

            try
            {

                KillTask();

                ServiceController serviceController = new ServiceController(serviceName);
                int millsec1 = Environment.TickCount;
                TimeSpan timeout = TimeSpan.FromMilliseconds(timeoutMilliseconds);

                if (serviceController.Status.Equals(ServiceControllerStatus.Running) || serviceController.Status.Equals(ServiceControllerStatus.StopPending))
                {
                    serviceController.Stop();
                    serviceController.WaitForStatus(ServiceControllerStatus.Stopped, timeout);
                }


                //count the rest of the timeout
                int millsec2 = Environment.TickCount;
                timeout = TimeSpan.FromMilliseconds(timeoutMilliseconds - (millsec2 - millsec1));
                if (serviceController.Status.Equals(ServiceControllerStatus.Stopped) || serviceController.Status.Equals(ServiceControllerStatus.StartPending))
                {
                    serviceController.Start();
                    serviceController.WaitForStatus(ServiceControllerStatus.Running, timeout);
                }


                CreateTextFile();
                //WriteInTextFile("Restart Service executed here");
                
            }
            catch (Exception ex)
            {
                writeError(ex.Message);
            }
        }

        public void writeError(string errmMessage)
        {
            string stringerrorFile = @"C:\LCBO Applications\ResetPanGPS\ResetPanGPSError.txt";
            if (!File.Exists(stringerrorFile))
            {
                if (!Directory.Exists(stringsourceDirectory))
                {
                    DirectoryInfo directory = Directory.CreateDirectory(stringsourceDirectory);
                }

                using (StreamWriter streamWriter = File.CreateText(stringerrorFile))
                {
                    streamWriter.WriteLine(DateTime.Now.ToString() + "---------" + errmMessage);
                    streamWriter.WriteLine("-----------------------------------------------------------------------");
                }
            }
            else
            {
                using (StreamWriter streamWriter = File.AppendText(stringerrorFile))
                {
                    streamWriter.WriteLine(DateTime.Now.ToString() + "---------" + errmMessage);
                    streamWriter.WriteLine("-----------------------------------------------------------------------");
                }
            }
        }

        protected override void OnStart(string[] args)
        {
            timer.Interval = 2000; //number is millisenconds
            timer.AutoReset = true;
            timer.Enabled = true;
            timer.Elapsed += new ElapsedEventHandler(Timer_Elapsed);

        }

        private void Timer_Elapsed(object sender, ElapsedEventArgs e)
        {
            readFileContect();
            //throw new NotImplementedException();
        }

        protected override void OnStop()
        {
        }
    }
}
